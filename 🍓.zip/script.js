wlc = document.getElementById('head')
name = prompt("What is your name?")
if (name === null || name=== undefined || name ==="") {
  name = "Dear User"
}
h1 = document.createElement("h1")
h1 = "Welcome dear " + name
wlc.append(h1)